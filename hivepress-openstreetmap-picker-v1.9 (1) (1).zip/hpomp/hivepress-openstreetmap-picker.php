<?php
/**
 * Plugin Name: HivePress OpenStreetMap Picker
 * Description: Interactive OpenStreetMap location picker for HivePress listing forms. Saves coordinates to hp_latitude/hp_longitude. Displays map automatically whenever coordinates are saved.
 * Version: 1.7
 * Author: Your Name
 * License: GPLv2 or later
 * Text Domain: hpomp
 *
 * REQUIRES:
 * - HivePress plugin active
 *
 * SHORTCODES:
 * [hpomp_picker]          — Map picker for add/edit listing forms
 * [hpomp_display]         — Displays the saved map on a single listing page
 * [hpomp_listings_map]    — Shows all listings with coordinates on one map
 */

defined( 'ABSPATH' ) || exit;

define( 'HPOMP_VERSION', '1.7' );
define( 'HPOMP_DIR', plugin_dir_path( __FILE__ ) );
define( 'HPOMP_URL', plugin_dir_url( __FILE__ ) );

/* ── Admin notice: HivePress missing ─────────────────────────────────── */
add_action( 'admin_notices', function() {
    if ( class_exists( 'HivePress\\Core' ) ) { return; }
    echo '<div class="notice notice-error"><p>'
        . '<strong>HivePress OpenStreetMap Picker:</strong> '
        . esc_html__( 'HivePress must be installed and active for this plugin to work.', 'hpomp' )
        . '</p></div>';
} );



/* ── 0. Enqueue Leaflet on single listing pages unconditionally ───────── */
add_action( 'wp_enqueue_scripts', function() {
    if ( ! is_singular( 'hp_listing' ) ) { return; }
    wp_enqueue_style(  'leaflet-css', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css', [], '1.9.4' );
    wp_enqueue_script( 'leaflet-js',  'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js',  [], '1.9.4', true );
} );

/* ── 1. Add hidden lat/lon fields to HivePress forms ─────────────────── */
add_filter( 'hivepress/v1/forms/listing_submit_details', function( $form ) {
    $form['fields']['latitude']  = [ 'type' => 'hidden', 'label' => false, 'default' => '' ];
    $form['fields']['longitude'] = [ 'type' => 'hidden', 'label' => false, 'default' => '' ];
    return $form;
} );

add_filter( 'hivepress/v1/forms/listing_update', function( $form ) {
    $listing_id = hivepress()->request->get_context( 'listing_id' );
    $form['fields']['latitude']  = [ 'type' => 'hidden', 'label' => false, 'default' => get_post_meta( $listing_id, 'hp_latitude',  true ) ];
    $form['fields']['longitude'] = [ 'type' => 'hidden', 'label' => false, 'default' => get_post_meta( $listing_id, 'hp_longitude', true ) ];
    return $form;
} );

/* ── 2. Save coordinates on create/update ────────────────────────────── */
add_action( 'hivepress/v1/models/listing/create', function( $listing_id, $values ) {
    if ( isset( $_POST['latitude'], $_POST['longitude'] ) ) {
        update_post_meta( $listing_id, 'hp_latitude',  sanitize_text_field( $_POST['latitude'] ) );
        update_post_meta( $listing_id, 'hp_longitude', sanitize_text_field( $_POST['longitude'] ) );
    }
}, 10, 2 );

add_action( 'hivepress/v1/models/listing/update', function( $listing_id, $values ) {
    if ( isset( $_POST['latitude'], $_POST['longitude'] ) ) {
        update_post_meta( $listing_id, 'hp_latitude',  sanitize_text_field( $_POST['latitude'] ) );
        update_post_meta( $listing_id, 'hp_longitude', sanitize_text_field( $_POST['longitude'] ) );
    }
}, 10, 2 );



/* ── 4. [hpomp_picker] ────────────────────────────────────────────────── */
function hpomp_picker_shortcode( $atts ) {
    if ( ! is_user_logged_in() ) { return ''; }

    $atts = shortcode_atts( [
        'lat'  => hpomp_get( 'hpomp_default_lat' ),
        'lon'  => hpomp_get( 'hpomp_default_lon' ),
        'zoom' => hpomp_get( 'hpomp_default_zoom' ),
    ], $atts, 'hpomp_picker' );

    wp_enqueue_style(  'leaflet-css', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css', [], '1.9.4' );
    wp_enqueue_script( 'leaflet-js',  'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js',  [], '1.9.4', true );

    ob_start();
    ?>
    <div class="hpomp-picker" style="margin:1.5em 0;">

        <div style="position:relative; margin-bottom:.5em;">
            <input type="text"
                   id="hpomp-search"
                   autocomplete="off"
                   placeholder="<?php esc_attr_e( 'Search for a location, city, lake or river…', 'hpomp' ); ?>"
                   style="width:100%; padding:.5em .5em .5em 2em; border:1px solid #ddd; border-radius:4px; box-sizing:border-box;">
            <span style="position:absolute; left:.55em; top:50%; transform:translateY(-50%); color:#aaa; pointer-events:none;">&#128269;</span>
            <ul id="hpomp-suggestions"
                style="display:none; position:absolute; top:100%; left:0; right:0; background:#fff;
                       border:1px solid #ddd; border-top:none; border-radius:0 0 4px 4px;
                       list-style:none; margin:0; padding:0; z-index:9999; box-shadow:0 4px 8px rgba(0,0,0,.1); max-height:200px; overflow-y:auto;"></ul>
        </div>

        <div id="hpomp-address"
             style="display:none; padding:.4em .6em; background:#f0f8e8; border:1px solid #b8dba0;
                    border-radius:4px; font-size:13px; color:#3a5a2a; margin-bottom:.5em;">
            <span style="margin-right:.4em;">&#128205;</span><span id="hpomp-address-text"></span>
        </div>

        <div id="hpomp-map" style="height:<?php echo intval( hpomp_get( 'hpomp_map_height' ) ); ?>px; border:1px solid #ddd; border-radius:4px;"></div>

        <div style="display:flex; align-items:center; gap:.75em; margin:.6em 0 0;">
            <button type="button" id="hpomp-locate"
                    style="display:inline-flex; align-items:center; gap:.4em; padding:.4em .9em;
                           background:#2271b1; color:#fff; border:none; border-radius:4px;
                           font-size:13px; cursor:pointer; white-space:nowrap;">
                <span>&#127759;</span>
                <?php esc_html_e( 'Use my location', 'hpomp' ); ?>
            </button>
            <span style="font-size:12px; color:#888;">
                <?php esc_html_e( 'or click on the map / drag the marker to set the exact location.', 'hpomp' ); ?>
            </span>
        </div>
    </div>

    <script>
    ( function() {
        var DEFAULT_LAT  = <?php echo (float) $atts['lat']; ?>;
        var DEFAULT_LON  = <?php echo (float) $atts['lon']; ?>;
        var DEFAULT_ZOOM = <?php echo (int) $atts['zoom']; ?>;
        var searchTimer  = null;

        function initMap() {
            if ( typeof L === 'undefined' ) { setTimeout( initMap, 100 ); return; }

            var container   = document.getElementById( 'hpomp-map' );
            if ( ! container || container._leaflet_id ) { return; }

            var latInput    = document.querySelector( 'input[name="latitude"]' );
            var lonInput    = document.querySelector( 'input[name="longitude"]' );
            var searchBox   = document.getElementById( 'hpomp-search' );
            var suggestions = document.getElementById( 'hpomp-suggestions' );
            var addrBox     = document.getElementById( 'hpomp-address' );
            var addrText    = document.getElementById( 'hpomp-address-text' );

            var initLat  = ( latInput && latInput.value ) ? parseFloat( latInput.value ) : DEFAULT_LAT;
            var initLon  = ( lonInput && lonInput.value ) ? parseFloat( lonInput.value ) : DEFAULT_LON;
            var initZoom = ( latInput && latInput.value ) ? 13 : DEFAULT_ZOOM;

            var map    = L.map( container ).setView( [ initLat, initLon ], initZoom );
            var marker = null;

            L.tileLayer( '<?php echo esc_js( hpomp_tile_url() ); ?>', {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            } ).addTo( map );

            if ( latInput && latInput.value && lonInput && lonInput.value ) {
                marker = L.marker( [ initLat, initLon ], { draggable: true } ).addTo( map );
                bindDrag();
                reverseGeocode( initLat, initLon );
            }

            function bindDrag() {
                marker.on( 'dragend', function() {
                    var pos = marker.getLatLng();
                    setCoords( pos.lat, pos.lng );
                    reverseGeocode( pos.lat, pos.lng );
                } );
            }

            function setCoords( lat, lon ) {
                if ( latInput ) { latInput.value = lat.toFixed(6); }
                if ( lonInput ) { lonInput.value = lon.toFixed(6); }
            }

            function placeMarker( lat, lon ) {
                if ( ! marker ) {
                    marker = L.marker( [ lat, lon ], { draggable: true } ).addTo( map );
                    bindDrag();
                } else {
                    marker.setLatLng( [ lat, lon ] );
                }
                map.setView( [ lat, lon ], 13 );
                setCoords( lat, lon );
            }

            function reverseGeocode( lat, lon ) {
                fetch( 'https://nominatim.openstreetmap.org/reverse?format=json&lat=' + lat + '&lon=' + lon )
                    .then( function( r ) { return r.json(); } )
                    .then( function( data ) {
                        if ( data && data.display_name ) {
                            addrText.textContent = data.display_name;
                            addrBox.style.display = 'block';
                        }
                    } )
                    .catch( function() {} );
            }

            map.on( 'click', function( e ) {
                placeMarker( e.latlng.lat, e.latlng.lng );
                reverseGeocode( e.latlng.lat, e.latlng.lng );
            } );

            // ── Locate Me ─────────────────────────────────────────────
            var locateBtn = document.getElementById( 'hpomp-locate' );
            if ( locateBtn ) {
                locateBtn.addEventListener( 'click', function() {
                    if ( ! navigator.geolocation ) {
                        alert( '<?php echo esc_js( __( 'Geolocation is not supported by your browser.', 'hpomp' ) ); ?>' );
                        return;
                    }
                    locateBtn.textContent = '<?php echo esc_js( __( 'Locating…', 'hpomp' ) ); ?>';
                    locateBtn.disabled = true;
                    navigator.geolocation.getCurrentPosition(
                        function( pos ) {
                            placeMarker( pos.coords.latitude, pos.coords.longitude );
                            reverseGeocode( pos.coords.latitude, pos.coords.longitude );
                            locateBtn.innerHTML = '<span>&#127759;</span> <?php echo esc_js( __( 'Use my location', 'hpomp' ) ); ?>';
                            locateBtn.disabled = false;
                        },
                        function( err ) {
                            var msgs = {
                                1: '<?php echo esc_js( __( 'Location access denied.', 'hpomp' ) ); ?>',
                                2: '<?php echo esc_js( __( 'Location unavailable.', 'hpomp' ) ); ?>',
                                3: '<?php echo esc_js( __( 'Location request timed out.', 'hpomp' ) ); ?>',
                            };
                            alert( msgs[ err.code ] || '<?php echo esc_js( __( 'Could not get your location.', 'hpomp' ) ); ?>' );
                            locateBtn.innerHTML = '<span>&#127759;</span> <?php echo esc_js( __( 'Use my location', 'hpomp' ) ); ?>';
                            locateBtn.disabled = false;
                        },
                        { enableHighAccuracy: true, timeout: 10000 }
                    );
                } );
            }

            // ── Autocomplete ───────────────────────────────────────────
            function hideSuggestions() {
                suggestions.style.display = 'none';
                suggestions.innerHTML = '';
            }

            function fetchSuggestions( query ) {
                fetch( 'https://nominatim.openstreetmap.org/search?format=json&q=' + encodeURIComponent( query ) + '&limit=5&addressdetails=1' )
                    .then( function( r ) { return r.json(); } )
                    .then( function( data ) {
                        suggestions.innerHTML = '';
                        if ( ! data || ! data.length ) { hideSuggestions(); return; }
                        data.forEach( function( item ) {
                            var li = document.createElement( 'li' );
                            li.textContent = item.display_name;
                            li.style.cssText = 'padding:.5em .75em; cursor:pointer; font-size:13px; border-bottom:1px solid #f0f0f0;';
                            li.addEventListener( 'mouseenter', function() { this.style.background = '#f5f5f5'; } );
                            li.addEventListener( 'mouseleave', function() { this.style.background = ''; } );
                            li.addEventListener( 'mousedown', function( e ) {
                                e.preventDefault();
                                searchBox.value = item.display_name;
                                placeMarker( parseFloat( item.lat ), parseFloat( item.lon ) );
                                reverseGeocode( parseFloat( item.lat ), parseFloat( item.lon ) );
                                hideSuggestions();
                            } );
                            suggestions.appendChild( li );
                        } );
                        suggestions.style.display = 'block';
                    } )
                    .catch( function() { hideSuggestions(); } );
            }

            searchBox.addEventListener( 'input', function() {
                var query = this.value.trim();
                clearTimeout( searchTimer );
                if ( query.length < 3 ) { hideSuggestions(); return; }
                searchTimer = setTimeout( function() { fetchSuggestions( query ); }, 400 );
            } );

            searchBox.addEventListener( 'keydown', function( e ) {
                if ( e.key === 'Escape' ) { hideSuggestions(); }
            } );

            document.addEventListener( 'click', function( e ) {
                if ( e.target !== searchBox ) { hideSuggestions(); }
            } );
        }

        if ( document.readyState === 'loading' ) {
            document.addEventListener( 'DOMContentLoaded', initMap );
        } else {
            initMap();
        }
    } )();
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode( 'hpomp_picker', 'hpomp_picker_shortcode' );

/* ── 5. [hpomp_display] ───────────────────────────────────────────────── */
function hpomp_display_shortcode() {
    $listing_id = null;

    if ( function_exists( 'hivepress' ) ) {
        $listing = hivepress()->request->get_context( 'listing' );
        if ( $listing && method_exists( $listing, 'get_id' ) ) {
            $listing_id = $listing->get_id();
        }
    }

    if ( ! $listing_id ) {
        $post = get_queried_object();
        if ( $post && isset( $post->ID ) && get_post_type( $post->ID ) === 'hp_listing' ) {
            $listing_id = $post->ID;
        }
    }

    if ( ! $listing_id ) { return ''; }

    $lat = get_post_meta( $listing_id, 'hp_latitude',  true );
    $lon = get_post_meta( $listing_id, 'hp_longitude', true );

    if ( ! $lat || ! $lon ) { return ''; }

    $map_id = 'hpomp-display-' . intval( $listing_id );
    $title  = esc_js( get_the_title( $listing_id ) );
    $zoom   = intval( hpomp_get( 'hpomp_display_zoom' ) );
    $tile   = esc_js( hpomp_tile_url() );

    ob_start();
    ?>
    <div id="<?php echo esc_attr( $map_id ); ?>"
         style="height:300px; margin:1.5em 0; border:1px solid #ddd; border-radius:4px;"></div>
    <script>
    ( function() {
        function initMap() {
            if ( typeof L === 'undefined' ) { setTimeout( initMap, 100 ); return; }
            var container = document.getElementById( '<?php echo esc_js( $map_id ); ?>' );
            if ( ! container || container._leaflet_id ) { return; }
            var map = L.map( container ).setView( [ <?php echo (float) $lat; ?>, <?php echo (float) $lon; ?> ], <?php echo $zoom; ?> );
            L.tileLayer( '<?php echo $tile; ?>', {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            } ).addTo( map );
            L.marker( [ <?php echo (float) $lat; ?>, <?php echo (float) $lon; ?> ] )
             .addTo( map )
             .bindPopup( '<strong><?php echo $title; ?></strong>' )
             .openPopup();
        }
        if ( document.readyState === 'loading' ) {
            document.addEventListener( 'DOMContentLoaded', initMap );
        } else {
            initMap();
        }
    } )();
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode( 'hpomp_display', 'hpomp_display_shortcode' );

/* ── 6. Admin settings page ───────────────────────────────────────────── */

add_action( 'admin_menu', function() {
    add_options_page(
        __( 'OpenStreetMap Picker Settings', 'hpomp' ),
        __( 'OSM Map Picker', 'hpomp' ),
        'manage_options',
        'hpomp-settings',
        'hpomp_settings_page'
    );
} );

add_action( 'admin_init', function() {
    register_setting( 'hpomp_settings', 'hpomp_default_lat',  [ 'sanitize_callback' => 'floatval', 'default' => 45.8  ] );
    register_setting( 'hpomp_settings', 'hpomp_default_lon',  [ 'sanitize_callback' => 'floatval', 'default' => 25.0  ] );
    register_setting( 'hpomp_settings', 'hpomp_default_zoom', [ 'sanitize_callback' => 'intval',   'default' => 7     ] );
    register_setting( 'hpomp_settings', 'hpomp_display_zoom', [ 'sanitize_callback' => 'intval',   'default' => 13    ] );
    register_setting( 'hpomp_settings', 'hpomp_map_height',   [ 'sanitize_callback' => 'intval',   'default' => 350   ] );
    register_setting( 'hpomp_settings', 'hpomp_tile_layer',   [ 'sanitize_callback' => 'sanitize_text_field', 'default' => 'osm' ] );
} );

function hpomp_get( $key ) {
    $defaults = [
        'hpomp_default_lat'  => 45.8,
        'hpomp_default_lon'  => 25.0,
        'hpomp_default_zoom' => 7,
        'hpomp_display_zoom' => 13,
        'hpomp_map_height'   => 350,
        'hpomp_tile_layer'   => 'osm',
    ];
    return get_option( $key, $defaults[ $key ] ?? '' );
}

function hpomp_tile_url( $layer = null ) {
    if ( ! $layer ) { $layer = hpomp_get( 'hpomp_tile_layer' ); }
    $layers = [
        'osm'   => 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
        'topo'  => 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png',
        'cycle' => 'https://{s}.tile-cyclosm.openstreetmap.fr/cyclosm/{z}/{x}/{y}.png',
    ];
    return $layers[ $layer ] ?? $layers['osm'];
}

function hpomp_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) { return; }
    ?>
    <div class="wrap">
        <h1><?php esc_html_e( 'HivePress OpenStreetMap Picker — Settings', 'hpomp' ); ?></h1>
        <p class="description">
            <?php esc_html_e( 'These settings control the default map center, zoom and tile layer. Shortcode attributes override these values when specified.', 'hpomp' ); ?>
        </p>

        <form method="post" action="options.php">
            <?php settings_fields( 'hpomp_settings' ); ?>

            <h2><?php esc_html_e( 'Default Map Center', 'hpomp' ); ?></h2>
            <p class="description"><?php esc_html_e( 'Used when no existing coordinates are found. Click the preview map to pick a location.', 'hpomp' ); ?></p>

            <table class="form-table" role="presentation">
                <tr>
                    <th><?php esc_html_e( 'Latitude', 'hpomp' ); ?></th>
                    <td><input type="number" step="0.0001" name="hpomp_default_lat" id="hpomp_default_lat"
                               value="<?php echo esc_attr( hpomp_get( 'hpomp_default_lat' ) ); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Longitude', 'hpomp' ); ?></th>
                    <td><input type="number" step="0.0001" name="hpomp_default_lon" id="hpomp_default_lon"
                               value="<?php echo esc_attr( hpomp_get( 'hpomp_default_lon' ) ); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Picker default zoom', 'hpomp' ); ?></th>
                    <td>
                        <input type="number" min="1" max="18" name="hpomp_default_zoom" id="hpomp_default_zoom"
                               value="<?php echo esc_attr( hpomp_get( 'hpomp_default_zoom' ) ); ?>" class="small-text">
                        <p class="description"><?php esc_html_e( '1 = world, 7 = country, 12 = city, 16 = street', 'hpomp' ); ?></p>
                    </td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Display zoom (listing page)', 'hpomp' ); ?></th>
                    <td>
                        <input type="number" min="1" max="18" name="hpomp_display_zoom"
                               value="<?php echo esc_attr( hpomp_get( 'hpomp_display_zoom' ) ); ?>" class="small-text">
                        <p class="description"><?php esc_html_e( 'Zoom level when showing map on a listing page.', 'hpomp' ); ?></p>
                    </td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Picker map height (px)', 'hpomp' ); ?></th>
                    <td><input type="number" min="150" max="800" step="10" name="hpomp_map_height"
                               value="<?php echo esc_attr( hpomp_get( 'hpomp_map_height' ) ); ?>" class="small-text"> px</td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Map tile layer', 'hpomp' ); ?></th>
                    <td>
                        <select name="hpomp_tile_layer" id="hpomp_tile_layer">
                            <option value="osm"   <?php selected( hpomp_get( 'hpomp_tile_layer' ), 'osm' ); ?>><?php esc_html_e( 'OpenStreetMap (standard)', 'hpomp' ); ?></option>
                            <option value="topo"  <?php selected( hpomp_get( 'hpomp_tile_layer' ), 'topo' ); ?>><?php esc_html_e( 'OpenTopoMap (terrain)', 'hpomp' ); ?></option>
                            <option value="cycle" <?php selected( hpomp_get( 'hpomp_tile_layer' ), 'cycle' ); ?>><?php esc_html_e( 'CyclOSM (cycling/outdoor)', 'hpomp' ); ?></option>
                        </select>
                    </td>
                </tr>
            </table>

            <h2><?php esc_html_e( 'Preview / Pick Default Center', 'hpomp' ); ?></h2>
            <p class="description"><?php esc_html_e( 'Click anywhere on the map to set the default center coordinates above.', 'hpomp' ); ?></p>
            <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
            <div id="hpomp-admin-map" style="height:300px; border:1px solid #ddd; border-radius:4px; margin-bottom:1.5em; max-width:800px;"></div>
            <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
            <script>
            ( function() {
                var latIn  = document.getElementById( 'hpomp_default_lat' );
                var lonIn  = document.getElementById( 'hpomp_default_lon' );
                var zoomIn = document.getElementById( 'hpomp_default_zoom' );
                var tileIn = document.getElementById( 'hpomp_tile_layer' );
                var tileLayers = {
                    osm:   'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
                    topo:  'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png',
                    cycle: 'https://{s}.tile-cyclosm.openstreetmap.fr/cyclosm/{z}/{x}/{y}.png',
                };
                var map = L.map( 'hpomp-admin-map' ).setView(
                    [ parseFloat( latIn.value ), parseFloat( lonIn.value ) ],
                    parseInt( zoomIn.value )
                );
                var tileLayer = L.tileLayer( tileLayers[ tileIn.value ] || tileLayers.osm, {
                    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                } ).addTo( map );
                var marker = L.marker( [ parseFloat( latIn.value ), parseFloat( lonIn.value ) ], { draggable: true } ).addTo( map );
                function updateInputs( lat, lon ) { latIn.value = lat.toFixed(4); lonIn.value = lon.toFixed(4); }
                map.on( 'click', function( e ) { marker.setLatLng( e.latlng ); updateInputs( e.latlng.lat, e.latlng.lng ); } );
                marker.on( 'dragend', function() { var p = marker.getLatLng(); updateInputs( p.lat, p.lng ); } );
                tileIn.addEventListener( 'change', function() {
                    map.removeLayer( tileLayer );
                    tileLayer = L.tileLayer( tileLayers[ this.value ] || tileLayers.osm, {
                        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                    } ).addTo( map );
                } );
            } )();
            </script>

            <?php submit_button( __( 'Save Settings', 'hpomp' ) ); ?>
        </form>

        <hr>
        <h2><?php esc_html_e( 'Shortcode Reference', 'hpomp' ); ?></h2>
        <table class="widefat" style="max-width:800px;">
            <thead><tr>
                <th><?php esc_html_e( 'Shortcode', 'hpomp' ); ?></th>
                <th><?php esc_html_e( 'Where to use', 'hpomp' ); ?></th>
                <th><?php esc_html_e( 'Optional attributes', 'hpomp' ); ?></th>
            </tr></thead>
            <tbody>
                <tr>
                    <td><code>[hpomp_picker]</code></td>
                    <td><?php esc_html_e( 'Listing submit / edit template', 'hpomp' ); ?></td>
                    <td><code>lat="45.8" lon="25.0" zoom="7"</code></td>
                </tr>
                <tr>
                    <td><code>[hpomp_display]</code></td>
                    <td><?php esc_html_e( 'Single listing template', 'hpomp' ); ?></td>
                    <td><?php esc_html_e( 'No attributes. Shows map whenever coordinates are saved.', 'hpomp' ); ?></td>
                </tr>
                <tr>
                    <td><code>[hpomp_listings_map]</code></td>
                    <td><?php esc_html_e( 'Any page', 'hpomp' ); ?></td>
                    <td><code>height="500" category="slug" limit="200"</code></td>
                </tr>
            </tbody>
        </table>


    </div>
    <?php
}

/* ── 7. [hpomp_listings_map] ─────────────────────────────────────────── */
function hpomp_listings_map_shortcode( $atts ) {
    $atts = shortcode_atts( [
        'height'   => '500',
        'category' => '',
        'limit'    => '200',
    ], $atts, 'hpomp_listings_map' );

    $query_args = [
        'post_type'      => 'hp_listing',
        'post_status'    => 'publish',
        'posts_per_page' => intval( $atts['limit'] ),
        'meta_query'     => [
            'relation' => 'AND',
            [ 'key' => 'hp_latitude',  'compare' => 'EXISTS' ],
            [ 'key' => 'hp_longitude', 'compare' => 'EXISTS' ],
        ],
    ];

    if ( $atts['category'] ) {
        $query_args['tax_query'] = [ [
            'taxonomy' => 'hp_listing_category',
            'field'    => is_numeric( $atts['category'] ) ? 'term_id' : 'slug',
            'terms'    => $atts['category'],
        ] ];
    }

    $listings = get_posts( $query_args );
    if ( empty( $listings ) ) {
        return '<p style="color:#888; font-style:italic;">' . esc_html__( 'No listings with map locations found.', 'hpomp' ) . '</p>';
    }

    $markers = [];
    foreach ( $listings as $listing ) {
        $lat = (float) get_post_meta( $listing->ID, 'hp_latitude',  true );
        $lon = (float) get_post_meta( $listing->ID, 'hp_longitude', true );
        if ( ! $lat || ! $lon ) { continue; }
        $thumb = get_the_post_thumbnail_url( $listing->ID, 'thumbnail' );
        $cats  = get_the_terms( $listing->ID, 'hp_listing_category' );
        $cat   = ( $cats && ! is_wp_error( $cats ) ) ? $cats[0]->name : '';
        $markers[] = [
            'lat'   => $lat,
            'lon'   => $lon,
            'title' => get_the_title( $listing->ID ),
            'url'   => get_permalink( $listing->ID ),
            'thumb' => $thumb ?: '',
            'cat'   => $cat,
        ];
    }

    if ( empty( $markers ) ) {
        return '<p style="color:#888; font-style:italic;">' . esc_html__( 'No listings with valid coordinates found.', 'hpomp' ) . '</p>';
    }

    wp_enqueue_style(  'leaflet-css', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css', [], '1.9.4' );
    wp_enqueue_script( 'leaflet-js',  'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js',  [], '1.9.4', true );

    $map_id       = 'hpomp-listings-map-' . uniqid();
    $markers_json = wp_json_encode( $markers );
    $tile_url     = esc_js( hpomp_tile_url() );
    $height       = intval( $atts['height'] );
    $count        = count( $markers );

    ob_start();
    ?>
    <div class="hpomp-listings-map-wrap" style="margin:1.5em 0;">
        <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:.5em; flex-wrap:wrap; gap:.5em;">
            <span style="font-size:13px; color:#666;">
                <?php printf( esc_html( _n( '%d listing on the map', '%d listings on the map', $count, 'hpomp' ) ), $count ); ?>
            </span>
            <button type="button" id="<?php echo esc_attr( $map_id ); ?>-fit"
                    style="padding:.3em .8em; font-size:12px; background:#f0f0f0; border:1px solid #ccc; border-radius:4px; cursor:pointer;">
                &#8982; <?php esc_html_e( 'Fit all markers', 'hpomp' ); ?>
            </button>
        </div>
        <div id="<?php echo esc_attr( $map_id ); ?>"
             style="height:<?php echo $height; ?>px; border:1px solid #ddd; border-radius:4px;"></div>
    </div>
    <script>
    ( function() {
        var markers = <?php echo $markers_json; ?>;
        function initMap() {
            if ( typeof L === 'undefined' ) { setTimeout( initMap, 100 ); return; }
            var container = document.getElementById( '<?php echo esc_js( $map_id ); ?>' );
            if ( ! container || container._leaflet_id ) { return; }
            var map   = L.map( container );
            var group = L.featureGroup();
            L.tileLayer( '<?php echo $tile_url; ?>', {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            } ).addTo( map );
            markers.forEach( function( m ) {
                var popup = '<div style="min-width:160px; max-width:220px; font-size:13px; line-height:1.4;">';
                if ( m.thumb ) {
                    popup += '<a href="' + m.url + '"><img src="' + m.thumb + '" style="width:100%; height:100px; object-fit:cover; border-radius:4px; display:block; margin-bottom:.5em;"></a>';
                }
                if ( m.cat ) { popup += '<span style="font-size:11px; color:#888; display:block; margin-bottom:.2em;">' + m.cat + '</span>'; }
                popup += '<a href="' + m.url + '" style="font-weight:600; color:#2271b1; text-decoration:none;">' + m.title + '</a></div>';
                L.marker( [ m.lat, m.lon ] ).bindPopup( popup, { maxWidth: 240 } ).addTo( map ).addTo( group );
            } );
            if ( group.getLayers().length ) { map.fitBounds( group.getBounds(), { padding: [ 30, 30 ] } ); }
            var fitBtn = document.getElementById( '<?php echo esc_js( $map_id ); ?>-fit' );
            if ( fitBtn ) { fitBtn.addEventListener( 'click', function() { map.fitBounds( group.getBounds(), { padding: [ 30, 30 ] } ); } ); }
        }
        if ( document.readyState === 'loading' ) {
            document.addEventListener( 'DOMContentLoaded', initMap );
        } else {
            initMap();
        }
    } )();
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode( 'hpomp_listings_map', 'hpomp_listings_map_shortcode' );
