const { __ } = wp.i18n;
const { registerBlockType } = wp.blocks;
const { PanelBody, SelectControl, RangeControl } = wp.components;
const { InspectorControls } = wp.editor;
const { Fragment } = wp.element;

const data = window.hpTopListingsData || {};
const slugs = data.slugs || {};
const names = data.names || {};

const categoryOptions = Object.entries(slugs).map(([id, slug]) => ({
    value: slug,
    label: names[id] || slug,
}));

registerBlockType('hp/top-listings', {
    title: __('HP Top Listings', 'hp-top-listings'),
    icon: 'chart-bar',
    category: 'widgets',
    description: __('Afișează topul înregistrărilor dintr-o categorie de pește.', 'hp-top-listings'),
    keywords: [__('top', 'hp-top-listings'), __('pește', 'hp-top-listings'), __('capturi', 'hp-top-listings')],

    attributes: {
        category: { type: 'string', default: '' },
        limit: { type: 'number', default: 3 },
    },

    edit: ({ attributes, setAttributes }) => {
        const { category, limit } = attributes;

        return (
            <Fragment>
                <InspectorControls>
                    <PanelBody title={__('Setări Top', 'hp-top-listings')} initialOpen={true}>
                        <SelectControl
                            label={__('Categorie', 'hp-top-listings')}
                            value={category}
                            options={[
                                { value: '', label: __('Selectează...', 'hp-top-listings') },
                                ...categoryOptions,
                            ]}
                            onChange={(value) => setAttributes({ category: value })}
                        />
                        <RangeControl
                            label={__('Număr de înregistrări', 'hp-top-listings')}
                            value={limit}
                            onChange={(value) => setAttributes({ limit: value })}
                            min={1}
                            max={20}
                        />
                    </PanelBody>
                </InspectorControls>

                <div style={{ padding: '20px', backgroundColor: '#f9f9f9', border: '1px dashed #888', borderRadius: '4px' }}>
                    <p style={{ margin: 0, fontSize: '14px', color: '#555' }}>
                        {category
                            ? `🏆 Top ${limit} – ${names[Object.keys(slugs).find(k => slugs[k] === category)] || category}`
                            : '⚠️ Selectează o categorie în panoul din dreapta'}
                    </p>
                </div>
            </Fragment>
        );
    },

    save: () => null, // render dinamic
});