<?php
defined( 'ABSPATH' ) || exit;

class HPCD_Scripts {

    public static function init() {
        add_action( 'wp_enqueue_scripts',    array( __CLASS__, 'frontend' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'admin_listing' ) );
    }

    /* ── Build the inline JS data object ────────────────────────────── */

    private static function build_inline_data() {
        $pairs = HPCD_DB::get_pairs( true );
        $out   = array();

        foreach ( $pairs as $pair ) {
            $map          = HPCD_DB::get_data_map( $pair->id );
            $category_ids = HPCD_Fields::get_category_ids( $pair );

            /*
             * Restructure map to: { parent_value: [child_value, ...] }
             * JS only needs an array of allowed children per parent value.
             */
            $rules = array();
            foreach ( $map as $pv => $children ) {
                // array_keys() returns integers for numeric-looking keys like "80", "90"
                // array_map('strval') forces them back to strings so json_encode
                // produces ["80","90"] (string array) not [80,90] (number array).
                $rules[ (string) $pv ] = array_values(
                    array_map( 'strval', array_keys( $children ) )
                );
            }
            // Cast to object so parent keys like "80" serialize as JSON object
            // property rather than being reindexed as array.
            $rules = (object) $rules;

            // Build icon HTML for JS display rewrite
            $p_bare     = HPCD_Fields::bare_icon( $pair->parent_icon );
            $c_bare     = HPCD_Fields::bare_icon( $pair->child_icon );
            $p_icon_html = $p_bare ? '<i class="hp-icon fas fa-fw fa-' . esc_attr( $p_bare ) . '"></i>' : '';
            $c_icon_html = $c_bare ? '<i class="hp-icon fas fa-fw fa-' . esc_attr( $c_bare ) . '"></i>' : '';

            $p_format = ! empty( $pair->parent_format ) ? $pair->parent_format : '%icon% %label%: %value%';
            $c_format = ! empty( $pair->child_format )  ? $pair->child_format  : '%icon% %label%: %value%';

            $out[ $pair->parent_field_name ] = array(
                'id'            => intval( $pair->id ),
                'parent_field'  => $pair->parent_field_name,
                'parent_label'  => $pair->parent_field_label,
                'parent_icon'   => $p_icon_html,
                'parent_format' => $p_format,
                'child_field'   => $pair->child_field_name,
                'child_label'   => $pair->child_field_label,
                'child_icon'    => $c_icon_html,
                'child_format'  => $c_format,
                'rules'         => $rules,
                'category_ids'  => $category_ids,
            );
        }

        return $out;
    }

    /* ── Frontend ────────────────────────────────────────────────────── */

    public static function frontend() {
        wp_enqueue_script(
            'hpcd-conditional',
            HPCD_URL . 'assets/js/conditional.js',
            array( 'jquery' ),
            HPCD_VERSION,
            true
        );

        wp_add_inline_script(
            'hpcd-conditional',
            'window.hpcdData = ' . wp_json_encode( self::build_inline_data() ) . ';',
            'before'
        );

        wp_enqueue_style( 'hpcd-frontend', HPCD_URL . 'assets/css/frontend.css', array(), HPCD_VERSION );
    }

    /* ── Admin listing edit page ─────────────────────────────────────── */

    public static function admin_listing( $hook ) {
        global $post_type;

        if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
            return;
        }
        if ( $post_type !== 'hp_listing' ) {
            return;
        }

        wp_enqueue_script(
            'hpcd-conditional',
            HPCD_URL . 'assets/js/conditional.js',
            array( 'jquery' ),
            HPCD_VERSION,
            true
        );

        wp_add_inline_script(
            'hpcd-conditional',
            'window.hpcdData = ' . wp_json_encode( self::build_inline_data() ) . ';',
            'before'
        );
    }
}
