=== HivePress Geolocation ===
Contributors: hivepress, eoxyar
Tags: hivepress, geolocation, maps, openstreetmap, leaflet
Requires at least: 5.0
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 2.0.0
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Allow users to search listings by location using OpenStreetMap and LeafletJS.

== Description ==

This extension allows users to search for listings by location using OpenStreetMap and LeafletJS. No API key required!

= Features =

* Location search with autocomplete (Nominatim)
* Interactive maps (LeafletJS)
* Marker clustering
* Geolocation detection ("Locate Me")
* Radius-based search filtering
* Region generation
* No API key required (free!)

== Installation ==

1. Upload the plugin files to `/wp-content/plugins/hivepress-geolocation`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Configure settings at HivePress > Settings > Geolocation

== Changelog ==

= 2.0.0 =
* Replaced Mapbox with LeafletJS and OpenStreetMap
* Replaced Mapbox Geocoder with Nominatim
* Added marker clustering support
* Removed API key requirement

= 1.3.7 =
* Initial MapLibre-based version
