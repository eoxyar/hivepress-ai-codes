<?php
/**
 * Plugin Name: HivePress Geolocation
 * Description: Allow users to search listings by location using OpenStreetMap and LeafletJS.
 * Version: 2.0.0
 * Author: HivePress & Modified by eoxyar
 * Author URI: 
 * Text Domain: hivepress-geolocation
 * Domain Path: /languages/
 *
 * @package HivePress
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

// Register extension directory.
add_filter(
	'hivepress/v1/extensions',
	function( $extensions ) {
		$extensions[] = __DIR__;

		return $extensions;
	}
);
