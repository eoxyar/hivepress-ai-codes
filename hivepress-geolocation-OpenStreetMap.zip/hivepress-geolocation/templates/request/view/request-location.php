<?php
/**
 * Request location template.
 *
 * @package HivePress\Templates
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( $request->get_location() ) :
	?>
	<div class="hp-request__location">
		<i class="hp-icon fas fa-map-marker-alt"></i>
		<span><?php echo esc_html( $request->get_location() ); ?></span>
	</div>
	<?php
endif;
