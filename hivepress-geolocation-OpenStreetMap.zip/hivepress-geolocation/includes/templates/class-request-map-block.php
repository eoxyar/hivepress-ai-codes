<?php
/**
 * Request map block template.
 *
 * @package HivePress\Templates
 */

namespace HivePress\Templates;

use HivePress\Helpers as hp;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Request map block template class.
 *
 * @class Request_Map_Block
 */
class Request_Map_Block extends Template {

	/**
	 * Class constructor.
	 *
	 * @param array $args Template arguments.
	 */
	public function __construct( $args = [] ) {
		$args = hp\merge_trees(
			[
				'blocks' => [
					'request_container' => [
						'type'       => 'container',
						'_order'     => 10,

						'attributes' => [
							'class' => [ 'hp-request', 'hp-request--map-block' ],
						],

						'blocks'     => [
							'request_content'        => [
								'type'       => 'container',
								'_order'     => 10,

								'attributes' => [
									'class' => [ 'hp-request__content' ],
								],

								'blocks'     => [
									'request_title' => [
										'type'   => 'part',
										'path'   => 'request/view/request-title',
										'_order' => 10,
									],
								],
							],

							'request_details_primary' => [
								'type'       => 'container',
								'_order'     => 20,

								'attributes' => [
									'class' => [ 'hp-request__details', 'hp-request__details--primary' ],
								],

								'blocks'     => [],
							],
						],
					],
				],
			],
			$args
		);

		parent::__construct( $args );
	}
}
