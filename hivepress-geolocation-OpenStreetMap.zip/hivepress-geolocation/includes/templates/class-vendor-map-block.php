<?php
/**
 * Vendor map block template.
 *
 * @package HivePress\Templates
 */

namespace HivePress\Templates;

use HivePress\Helpers as hp;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Vendor map block template class.
 *
 * @class Vendor_Map_Block
 */
class Vendor_Map_Block extends Template {

	/**
	 * Class constructor.
	 *
	 * @param array $args Template arguments.
	 */
	public function __construct( $args = [] ) {
		$args = hp\merge_trees(
			[
				'blocks' => [
					'vendor_container' => [
						'type'       => 'container',
						'_order'     => 10,

						'attributes' => [
							'class' => [ 'hp-vendor', 'hp-vendor--map-block' ],
						],

						'blocks'     => [
							'vendor_image'          => [
								'type'   => 'part',
								'path'   => 'vendor/view/vendor-image',
								'_order' => 10,
							],

							'vendor_content'        => [
								'type'       => 'container',
								'_order'     => 20,

								'attributes' => [
									'class' => [ 'hp-vendor__content' ],
								],

								'blocks'     => [
									'vendor_name' => [
										'type'   => 'part',
										'path'   => 'vendor/view/vendor-name',
										'_order' => 10,
									],
								],
							],

							'vendor_details_primary' => [
								'type'       => 'container',
								'_order'     => 30,

								'attributes' => [
									'class' => [ 'hp-vendor__details', 'hp-vendor__details--primary' ],
								],

								'blocks'     => [],
							],
						],
					],
				],
			],
			$args
		);

		parent::__construct( $args );
	}
}
