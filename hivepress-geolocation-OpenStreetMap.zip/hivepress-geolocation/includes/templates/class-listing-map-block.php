<?php
/**
 * Listing map block template.
 *
 * @package HivePress\Templates
 */

namespace HivePress\Templates;

use HivePress\Helpers as hp;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Listing map block template class.
 *
 * @class Listing_Map_Block
 */
class Listing_Map_Block extends Template {

	/**
	 * Class constructor.
	 *
	 * @param array $args Template arguments.
	 */
	public function __construct( $args = [] ) {
		$args = hp\merge_trees(
			[
				'blocks' => [
					'listing_container' => [
						'type'       => 'container',
						'_order'     => 10,

						'attributes' => [
							'class' => [ 'hp-listing', 'hp-listing--map-block' ],
						],

						'blocks'     => [
							'listing_image'          => [
								'type'   => 'part',
								'path'   => 'listing/view/listing-image',
								'_order' => 10,
							],

							'listing_content'        => [
								'type'       => 'container',
								'_order'     => 20,

								'attributes' => [
									'class' => [ 'hp-listing__content' ],
								],

								'blocks'     => [
									'listing_title' => [
										'type'   => 'part',
										'path'   => 'listing/view/listing-title',
										'_order' => 10,
									],
								],
							],

							'listing_details_primary' => [
								'type'       => 'container',
								'_order'     => 30,

								'attributes' => [
									'class' => [ 'hp-listing__details', 'hp-listing__details--primary' ],
								],

								'blocks'     => [],
							],
						],
					],
				],
			],
			$args
		);

		parent::__construct( $args );
	}
}
