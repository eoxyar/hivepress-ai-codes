<?php
/**
 * Plugin Name: HP Top Listings Block
 * Description: Gutenberg block and shortcode to list listings by category in ListingHive. Shortcode: [hp_top category="your-category" limit="3"]
 * Version: 1.1
 * Author: you
 * Text Domain: hp-top-listings
 */

if (!defined('ABSPATH')) exit;

define('HP_TOP_LISTINGS_PLUGIN_URL', plugin_dir_url(__FILE__));
define('HP_TOP_LISTINGS_PLUGIN_DIR', plugin_dir_path(__FILE__));

// Shortcode: [hp_top category="your-category" limit="3"]
add_shortcode('hp_top', 'hp_top_shortcode');
function hp_top_shortcode($atts) {
    $atts = shortcode_atts([
        'category' => '',
        'limit'    => 3,
    ], $atts);

    if (empty($atts['category'])) {
        return '<p style="color:red;">The "category" parameter is missing from the shortcode.</p>';
    }

    $slug  = sanitize_text_field($atts['category']);
    $limit = intval($atts['limit']);

    $term = get_term_by('slug', $slug, 'hp_listing_category');
    if (!$term || is_wp_error($term)) {
        return '<p>Category "' . esc_html($slug) . '" does not exist.</p>';
    }

    ob_start();
    echo '<div class="hp-top-category hp-top-' . esc_attr($slug) . '">';
    echo '<h3 style="font-size:18px; margin-bottom:15px;">Latest ' . $limit . ' - ' . esc_html($term->name) . '</h3>';

    $q = new WP_Query([
        'post_type'      => 'hp_listing',
        'posts_per_page' => $limit,
        'post_status'    => 'publish',
        'orderby'        => 'date',
        'order'          => 'DESC',
        'tax_query'      => [[
            'taxonomy' => 'hp_listing_category',
            'field'    => 'term_id',
            'terms'    => $term->term_id,
        ]],
    ]);

    if ($q->have_posts()) {
        while ($q->have_posts()) {
            $q->the_post();
            $id     = get_the_ID();
            $title  = get_the_title();
            $link   = get_permalink();
            $thumb  = get_the_post_thumbnail_url($id, 'thumbnail');
            $author = get_the_author_meta('display_name', get_post_field('post_author', $id));

            if (!$thumb) {
                $thumb = 'https://via.placeholder.com/80x80?text=No+Img';
            }

            echo '
            <div style="display:flex; align-items:center; gap:7px; padding:5px; border-bottom:1px solid #eee;">
                <img src="' . esc_url($thumb) . '" style="width:50px; height:50px; object-fit:cover; border-radius:6px;">
                <div style="flex:1;">
                    <div style="font-size:14px; font-weight:600;">
                        ' . esc_html($title) . ' By: <strong>' . esc_html($author) . '</strong>
                    </div>
                </div>
                <a href="' . esc_url($link) . '" style="font-size:22px; color:#28a745; text-decoration:none;">&gt;</a>
            </div>';
        }

        echo '<p style="text-align:center; margin-top:15px;">
            <a href="' . esc_url(home_url('/?post_type=hp_listing&s=&_category=' . $term->term_id)) . '"
               style="color:#84bd1c; text-decoration:underline;">View all</a>
        </p>';
    } else {
        echo '<p style="color:#777;">No listings found for ' . esc_html($term->name) . ' yet.</p>';
    }

    wp_reset_postdata();
    echo '</div>';
    return ob_get_clean();
}

// Register the Gutenberg block
function hp_register_top_listings_block() {
    if (!function_exists('register_block_type')) return;

    wp_register_script(
        'hp-top-listings-block-script',
        HP_TOP_LISTINGS_PLUGIN_URL . 'blocks/hp-top-listings/index.js',
        ['wp-blocks', 'wp-element', 'wp-editor', 'wp-components', 'wp-i18n'],
        '1.1.0',
        true
    );

    $terms = get_terms([
        'taxonomy'   => 'hp_listing_category',
        'hide_empty' => false,
        'fields'     => 'id=>slug',
    ]);
    $term_names = get_terms([
        'taxonomy'   => 'hp_listing_category',
        'hide_empty' => false,
        'fields'     => 'id=>name',
    ]);

    wp_localize_script(
        'hp-top-listings-block-script',
        'hpTopListingsData',
        [
            'slugs' => $terms,
            'names' => $term_names,
        ]
    );

    register_block_type('hp/top-listings', [
        'editor_script'   => 'hp-top-listings-block-script',
        'render_callback' => 'hp_top_listings_render_callback',
        'attributes'      => [
            'category' => ['type' => 'string', 'default' => ''],
            'limit'    => ['type' => 'number', 'default' => 3],
        ],
    ]);
}
add_action('init', 'hp_register_top_listings_block');

function hp_top_listings_render_callback($attributes) {
    $category = isset($attributes['category']) ? $attributes['category'] : '';
    $limit    = isset($attributes['limit']) ? (int) $attributes['limit'] : 3;
    return do_shortcode('[hp_top category="' . esc_attr($category) . '" limit="' . $limit . '"]');
}
