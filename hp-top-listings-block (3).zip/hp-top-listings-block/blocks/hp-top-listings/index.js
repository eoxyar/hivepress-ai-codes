const { __ } = wp.i18n;
const { registerBlockType } = wp.blocks;
const { PanelBody, SelectControl, RangeControl } = wp.components;
const { InspectorControls } = wp.editor;
const { Fragment } = wp.element;

const data = window.hpTopListingsData || {};
const slugs = data.slugs || {};
const names = data.names || {};

const categoryOptions = Object.entries(slugs).map(([id, slug]) => ({
    value: slug,
    label: names[id] || slug,
}));

registerBlockType('hp/top-listings', {
    title: __('HP Top Listings', 'hp-top-listings'),
    icon: 'chart-bar',
    category: 'widgets',
    description: __('Displays the latest listings from a selected category.', 'hp-top-listings'),
    keywords: [__('top', 'hp-top-listings'), __('listings', 'hp-top-listings'), __('latest', 'hp-top-listings')],

    attributes: {
        category: { type: 'string', default: '' },
        limit: { type: 'number', default: 3 },
    },

    edit: ({ attributes, setAttributes }) => {
        const { category, limit } = attributes;

        return (
            <Fragment>
                <InspectorControls>
                    <PanelBody title={__('Block Settings', 'hp-top-listings')} initialOpen={true}>
                        <SelectControl
                            label={__('Category', 'hp-top-listings')}
                            value={category}
                            options={[
                                { value: '', label: __('Select a category...', 'hp-top-listings') },
                                ...categoryOptions,
                            ]}
                            onChange={(value) => setAttributes({ category: value })}
                        />
                        <RangeControl
                            label={__('Number of listings', 'hp-top-listings')}
                            value={limit}
                            onChange={(value) => setAttributes({ limit: value })}
                            min={1}
                            max={20}
                        />
                    </PanelBody>
                </InspectorControls>

                <div style={{ padding: '20px', backgroundColor: '#f9f9f9', border: '1px dashed #888', borderRadius: '4px' }}>
                    <p style={{ margin: 0, fontSize: '14px', color: '#555' }}>
                        {category
                            ? `🏆 Latest ${limit} – ${names[Object.keys(slugs).find(k => slugs[k] === category)] || category}`
                            : '⚠️ Select a category in the right panel'}
                    </p>
                </div>
            </Fragment>
        );
    },

    save: () => null, // dynamic render
});
