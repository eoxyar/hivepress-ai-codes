/**
 * HivePress Multi-Step Form - Frontend Wizard v1.7.7
 *
 * No CSS pre-hiding. JS hides/shows fields directly via inline style.
 * Watches document.body for HP replacing the entire form on category change.
 */
( function ( $ ) {
    'use strict';

    var CFG          = window.hpmsfData || {};
    var defaultSteps = CFG.defaultSteps || [];
    var catMap       = CFG.catMap       || {};
    var style        = CFG.style        || 'progress';
    var i18n         = CFG.i18n         || {};

    if ( ! defaultSteps.length && ! Object.keys( catMap ).length ) { return; }

    var currentStep   = 0;
    var stepGroups    = [];
    var $wizardHeader = null;
    var $wizardNav    = null;
    var bodyObserver  = null;
    var reinitTimer   = null;
    var activeForm    = null;

    /* ── Boot ─────────────────────────────────────────────────────────── */
    function boot() {
        var form = findListingForm();
        if ( form ) { initWizard( form ); }
        watchBody();
    }

    function findListingForm() {
        return document.querySelector( 'form.hp-form--listing-submit' );
    }

    /* ── Watch body for HP replacing the entire form ──────────────────── */
    function watchBody() {
        if ( bodyObserver ) { bodyObserver.disconnect(); }
        if ( ! window.MutationObserver ) { return; }

        bodyObserver = new MutationObserver( function( mutations ) {
            var found = false;
            mutations.forEach( function( m ) {
                m.addedNodes.forEach( function( n ) {
                    if ( n.nodeType !== 1 ) { return; }
                    if ( ( n.matches && n.matches( 'form.hp-form--listing-submit' ) ) ||
                         ( n.querySelector && n.querySelector( 'form.hp-form--listing-submit' ) ) ) {
                        found = true;
                    }
                } );
            } );
            if ( ! found ) { return; }
            clearTimeout( reinitTimer );
            reinitTimer = setTimeout( function() {
                var freshForm = findListingForm();
                if ( freshForm && freshForm !== activeForm ) {
                    initWizard( freshForm );
                }
            }, 300 );
        } );

        bodyObserver.observe( document.body, { childList: true, subtree: true } );
    }

    /* ── Init wizard ─────────────────────────────────────────────────── */
    function initWizard( form ) {
        activeForm  = form;
        currentStep = 0;

        var catSel = form.querySelector( 'select[name="categories"], select[name="categories[]"]' );
        var activeSteps = defaultSteps;
        if ( catSel && catSel.value ) {
            activeSteps = getStepsForCategory( catSel.value );
        }

        var allWrappers = getTopLevelWrappers( form );
        stepGroups      = distributeIntoSteps( allWrappers, activeSteps );
        if ( ! stepGroups.length ) { return; }

        // Hide ALL wrappers first with inline style
        allWrappers.forEach( function( w ) { w.style.setProperty( 'display', 'none', 'important' ); } );

        // Remove old wizard UI
        $( '.hpmsf-header' ).remove();
        $( '.hpmsf-nav' ).remove();
        $wizardHeader = null;
        $wizardNav    = null;

        $wizardHeader = buildHeader();
        $wizardNav    = buildNav();
        $( form ).before( $wizardHeader );
        var $footer = $( form ).find( '.hp-form__footer' );
        if ( $footer.length ) { $footer.before( $wizardNav ); }
        else { $( form ).append( $wizardNav ); }

        bindNavEvents( form );
        applyStep();
    }

    /* ── Pattern lookup ──────────────────────────────────────────────── */
    function getStepsForCategory( catId ) {
        var key = String( catId );
        if ( catMap[ key ] && catMap[ key ].length >= 2 ) { return catMap[ key ]; }
        return defaultSteps.length ? defaultSteps : [];
    }

    /* ── Distribute fields into steps ────────────────────────────────── */
    function distributeIntoSteps( allWrappers, steps ) {
        var groups = [];
        var cursor = 0;
        steps.forEach( function( step, i ) {
            var isLast   = ( i === steps.length - 1 );
            var count    = parseInt( step.count, 10 ) || 0;
            var wrappers = isLast
                ? allWrappers.slice( cursor )
                : allWrappers.slice( cursor, cursor + count );
            if ( ! isLast ) { cursor += count; }
            if ( wrappers.length ) {
                groups.push( { title: step.title || '', wrappers: wrappers } );
            }
        } );
        if ( ! groups.length && allWrappers.length ) {
            groups.push( { title: '', wrappers: allWrappers } );
        }
        return groups;
    }

    /* ── Get top-level field wrappers ────────────────────────────────── */
    function getTopLevelWrappers( form ) {
        var all = Array.prototype.slice.call(
            form.querySelectorAll( '.hp-form__field, .hp-field' )
        );
        return all.filter( function( el ) {
            if ( el.querySelector( 'button[type="submit"]' ) ) { return false; }
            if ( el.classList.contains( 'hp-form__footer' ) )  { return false; }
            var p = el.parentElement;
            while ( p && p !== form ) {
                if ( p.classList.contains( 'hp-form__field' ) ||
                     p.classList.contains( 'hp-field' ) ) { return false; }
                p = p.parentElement;
            }
            return true;
        } );
    }

    /* ── Apply step ──────────────────────────────────────────────────── */
    function applyStep() {
        currentStep = Math.max( 0, Math.min( currentStep, stepGroups.length - 1 ) );

        // Hide all
        stepGroups.forEach( function( g ) {
            g.wrappers.forEach( function( w ) {
                w.style.setProperty( 'display', 'none', 'important' );
            } );
        } );

        // Show current step — remove the inline style so the element's natural display applies
        stepGroups[ currentStep ].wrappers.forEach( function( w ) {
            w.style.removeProperty( 'display' );
        } );

        var isFirst = currentStep === 0;
        var isLast  = currentStep === stepGroups.length - 1;

        $wizardNav.find( '.hpmsf-btn-back' ).toggle( ! isFirst );
        $wizardNav.find( '.hpmsf-btn-next' ).toggle( ! isLast );
        $wizardNav.find( '.hpmsf-btn-submit' ).toggle( isLast );
        $wizardNav.find( '.hpmsf-counter' ).text(
            ( i18n.step || 'Step' ) + ' ' + ( currentStep + 1 ) +
            ' ' + ( i18n.of || 'of' ) + ' ' + stepGroups.length
        );
        updateHeader();
    }

    /* ── Nav events ──────────────────────────────────────────────────── */
    function bindNavEvents( form ) {
        $wizardNav.find( '.hpmsf-btn-next' ).on( 'click', function() {
            if ( ! validateStep() ) {
                showError( i18n.required || 'Please fill in all required fields.' );
                return;
            }
            hideError(); currentStep++; applyStep(); scrollUp();
        } );

        $wizardNav.on( 'click', '.hpmsf-btn-back', function() {
            hideError(); currentStep--; applyStep(); scrollUp();
        } );

        $wizardNav.find( '.hpmsf-btn-submit' ).on( 'click', function() {
            var footer = form.querySelector( '.hp-form__footer' );
            var orig   = form.querySelector(
                '.hp-form__button--submit, button[type="submit"], input[type="submit"]'
            );
            if ( orig ) {
                // Briefly show footer so HP can submit, then re-hide
                if ( footer ) { footer.style.setProperty( 'display', 'block', 'important' ); }
                orig.click();
                setTimeout( function() {
                    if ( footer ) { footer.style.removeProperty( 'display' ); }
                }, 200 );
            } else {
                form.submit();
            }
        } );

        $wizardHeader.on( 'click', '.hpmsf-step-dot.is-completed', function() {
            var t = parseInt( $( this ).data( 'step' ), 10 );
            if ( ! isNaN(t) && t < currentStep ) { currentStep = t; applyStep(); scrollUp(); }
        } );
    }

    /* ── Validate ────────────────────────────────────────────────────── */
    function validateStep() {
        var valid = true;
        if ( ! stepGroups[ currentStep ] ) { return true; }
        stepGroups[ currentStep ].wrappers.forEach( function( w ) {
            var inputs = w.querySelectorAll(
                'input[required]:not([type=hidden]), select[required], textarea[required]'
            );
            inputs.forEach( function( inp ) {
                var empty = ! inp.value;
                $( w ).toggleClass( 'hpmsf-field-error', empty );
                if ( empty ) { valid = false; }
            } );
        } );
        return valid;
    }

    /* ── UI builders ─────────────────────────────────────────────────── */
    function buildHeader() {
        var $h = $( '<div>' ).addClass( 'hpmsf-header hpmsf-style-' + style );
        if ( style !== 'minimal' ) {
            var $dots = $( '<div>' ).addClass( 'hpmsf-dots' );
            stepGroups.forEach( function( g, i ) {
                $dots.append(
                    $( '<div>' ).addClass( 'hpmsf-step-dot' ).attr( 'data-step', i ).html(
                        '<span class="hpmsf-dot-num">' + ( i + 1 ) + '</span>' +
                        '<span class="hpmsf-dot-label">' + esc( g.title ) + '</span>'
                    )
                );
                if ( i < stepGroups.length - 1 ) {
                    $dots.append( $( '<div>' ).addClass( 'hpmsf-dot-connector' ) );
                }
            } );
            $h.append( $dots );
        }
        if ( style === 'progress' ) {
            $h.append( $( '<div>' ).addClass( 'hpmsf-progress-bar' ).append(
                $( '<div>' ).addClass( 'hpmsf-progress-fill' )
            ) );
        }
        $h.append( $( '<div>' ).addClass( 'hpmsf-step-title' ).append(
            $( '<span>' ).addClass( 'hpmsf-current-title' )
        ) );
        return $h;
    }

    function buildNav() {
        return $( '<div>' ).addClass( 'hpmsf-nav' ).html(
            '<button type="button" class="hpmsf-btn hpmsf-btn-back">&#8592; ' + esc( i18n.back || 'Back' ) + '</button>' +
            '<span class="hpmsf-counter"></span>' +
            '<button type="button" class="hpmsf-btn hpmsf-btn-next">' + esc( i18n.next || 'Next' ) + ' &#8594;</button>' +
            '<button type="button" class="hpmsf-btn hpmsf-btn-submit" style="display:none">' + esc( i18n.submit || 'Submit Listing' ) + '</button>'
        );
    }

    function updateHeader() {
        if ( ! $wizardHeader ) { return; }
        var pct = Math.round( ( ( currentStep + 1 ) / stepGroups.length ) * 100 );
        $wizardHeader.find( '.hpmsf-progress-fill' ).css( 'width', pct + '%' );
        $wizardHeader.find( '.hpmsf-current-title' ).text(
            stepGroups[ currentStep ] ? stepGroups[ currentStep ].title : ''
        );
        $wizardHeader.find( '.hpmsf-step-dot' ).each( function( i ) {
            $( this )
                .toggleClass( 'is-active',    i === currentStep )
                .toggleClass( 'is-completed', i < currentStep );
        } );
    }

    function showError( msg ) {
        var $m = $wizardNav.find( '.hpmsf-validation-msg' );
        if ( ! $m.length ) { $m = $( '<p>' ).addClass( 'hpmsf-validation-msg' ).prependTo( $wizardNav ); }
        $m.text( msg ).show();
    }
    function hideError() { $wizardNav && $wizardNav.find( '.hpmsf-validation-msg' ).hide(); }

    function scrollUp() {
        if ( $wizardHeader ) {
            $( 'html,body' ).animate( { scrollTop: $wizardHeader.offset().top - 80 }, 250 );
        }
    }
    function esc( s ) {
        return ( s || '' ).replace( /&/g, '&amp;' ).replace( /</g, '&lt;' ).replace( />/g, '&gt;' );
    }

    /* ── Start ───────────────────────────────────────────────────────── */
    if ( document.readyState === 'loading' ) {
        document.addEventListener( 'DOMContentLoaded', boot );
    } else {
        boot();
    }

} )( window.jQuery );
