/**
 * HivePress Multi-Step Form - Admin JS v1.7.0
 * Patterns: each with name, category assignment, steps with counts.
 */
( function( $ ) {
    'use strict';

    var fields     = window.hpmsfAdmin ? window.hpmsfAdmin.fields     : [];
    var categories = window.hpmsfAdmin ? window.hpmsfAdmin.categories : [];
    var i18n       = window.hpmsfAdmin ? window.hpmsfAdmin.i18n       : {};
    var total      = fields.length;
    var patternCount = $( '.hpmsf-pattern-card' ).length;

    var STEP_COLORS = [
        '#2271b1', '#46b450', '#e65054',
        '#f56e28', '#9b59b6', '#1abc9c',
        '#f39c12', '#e74c3c'
    ];

    /* ── Set default ──────────────────────────────────────────────────── */

    $( document ).on( 'click', '.hpmsf-set-default', function() {
        var id = $( this ).data( 'id' );
        $( '#hpmsf-default-pattern-input' ).val( id );

        // Update UI — remove old default badge, add to this card
        $( '.hpmsf-default-badge' ).each( function() {
            var $old = $( this );
            var oldId = $old.closest( '.hpmsf-pattern-card' ).data( 'pattern-id' );
            $old.replaceWith(
                '<button type="button" class="hpmsf-set-default button button-small" data-id="' + oldId + '">' +
                i18n.setDefault + '</button>'
            );
        } );

        $( this ).replaceWith( '<span class="hpmsf-default-badge">DEFAULT</span>' );

        // Hide/show category section (default has no category picker)
        $( '.hpmsf-pattern-card' ).each( function() {
            var $card   = $( this );
            var cardId  = $card.data( 'pattern-id' );
            var $catSec = $card.find( '.hpmsf-pattern-categories' );
            if ( parseInt( cardId ) === parseInt( id ) ) {
                $catSec.hide();
            } else {
                $catSec.show();
            }
        } );
    } );

    /* ── Enforce one category → one pattern ──────────────────────────── */

    $( document ).on( 'change', '.hpmsf-cat-checkboxes input[type="checkbox"]', function() {
        var $cb    = $( this );
        var catId  = $cb.val();
        var $card  = $cb.closest( '.hpmsf-pattern-card' );

        if ( $cb.is( ':checked' ) ) {
            // Uncheck same category in all other patterns
            $( '.hpmsf-cat-checkboxes input[value="' + catId + '"]' )
                .not( $cb )
                .prop( 'checked', false );
        }
    } );

    /* ── Add pattern ──────────────────────────────────────────────────── */

    $( '#hpmsf-add-pattern' ).on( 'click', function() {
        var pi  = patternCount++;
        var pid = Date.now(); // unique id
        var $card = buildPatternCard( pi, pid );
        $( '#hpmsf-patterns-list' ).append( $card );
        updatePatternPreview( $card );
    } );

    /* ── Remove pattern ───────────────────────────────────────────────── */

    $( document ).on( 'click', '.hpmsf-remove-pattern', function() {
        var $card = $( this ).closest( '.hpmsf-pattern-card' );
        if ( $card.hasClass( 'is-default' ) ) {
            alert( 'Cannot delete the default pattern. Set another pattern as default first.' );
            return;
        }
        $card.remove();
        reindexPatterns();
    } );

    /* ── Add step ─────────────────────────────────────────────────────── */

    $( document ).on( 'click', '.hpmsf-add-step', function() {
        var $card = $( this ).closest( '.hpmsf-pattern-card' );
        var pi    = $card.data( 'pattern-index' );
        var $list = $card.find( '.hpmsf-steps-list' );
        var si    = $list.find( '.hpmsf-step-row' ).length;
        $list.append( buildStepRow( pi, si ) );
        reindexSteps( $card );
        updatePatternPreview( $card );
    } );

    /* ── Remove step ──────────────────────────────────────────────────── */

    $( document ).on( 'click', '.hpmsf-remove-step', function() {
        var $card = $( this ).closest( '.hpmsf-pattern-card' );
        $( this ).closest( '.hpmsf-step-row' ).remove();
        reindexSteps( $card );
        updatePatternPreview( $card );
    } );

    /* ── Update preview on count/name change ─────────────────────────── */

    $( document ).on( 'input change', '.hpmsf-step-count-input', function() {
        updatePatternPreview( $( this ).closest( '.hpmsf-pattern-card' ) );
    } );

    /* ── Reindex all patterns ─────────────────────────────────────────── */

    function reindexPatterns() {
        $( '.hpmsf-pattern-card' ).each( function( pi ) {
            var $card = $( this );
            $card.attr( 'data-pattern-index', pi );
            $card.find( '> input[name*="[id]"]' )
                 .attr( 'name', 'hpmsf_patterns[' + pi + '][id]' );
            $card.find( '.hpmsf-pattern-name-input' )
                 .attr( 'name', 'hpmsf_patterns[' + pi + '][name]' );
            $card.find( '.hpmsf-cat-checkboxes input' ).each( function() {
                var val = $( this ).val();
                $( this ).attr( 'name', 'hpmsf_patterns[' + pi + '][categories][]' );
            } );
            $card.find( '.hpmsf-add-step' ).attr( 'data-pattern', pi );
            $card.find( '.hpmsf-steps-list' ).attr( 'data-pattern', pi );
            $card.find( '.hpmsf-visual-fields' ).attr( 'data-pattern', pi );
            reindexSteps( $card );
        } );
        patternCount = $( '.hpmsf-pattern-card' ).length;
    }

    function reindexSteps( $card ) {
        var pi = $card.data( 'pattern-index' );
        $card.find( '.hpmsf-step-row' ).each( function( si ) {
            $( this ).find( '.hpmsf-step-num-badge' ).text( si + 1 );
            $( this ).find( '.hpmsf-step-title-input' )
                     .attr( 'name', 'hpmsf_patterns[' + pi + '][steps][' + si + '][title]' );
            $( this ).find( '.hpmsf-step-count-input' )
                     .attr( 'name', 'hpmsf_patterns[' + pi + '][steps][' + si + '][count]' );
        } );
    }

    /* ── Build pattern card HTML ──────────────────────────────────────── */

    function buildPatternCard( pi, pid ) {
        var catBoxes = '';
        categories.forEach( function( cat ) {
            catBoxes +=
                '<label class="hpmsf-cat-label">' +
                    '<input type="checkbox" name="hpmsf_patterns[' + pi + '][categories][]" value="' + cat.id + '"> ' +
                    escHtml( cat.name ) +
                '</label>';
        } );

        return $(
            '<div class="hpmsf-pattern-card" data-pattern-index="' + pi + '" data-pattern-id="' + pid + '">' +
                '<input type="hidden" name="hpmsf_patterns[' + pi + '][id]" value="' + pid + '">' +
                '<div class="hpmsf-pattern-header">' +
                    '<div class="hpmsf-pattern-header-left">' +
                        '<button type="button" class="hpmsf-set-default button button-small" data-id="' + pid + '">Set as Default</button>' +
                        '<input type="text" name="hpmsf_patterns[' + pi + '][name]" placeholder="Pattern name\u2026" class="hpmsf-pattern-name-input regular-text">' +
                    '</div>' +
                    '<button type="button" class="hpmsf-remove-pattern button-link">' +
                        '<span class="dashicons dashicons-trash"></span> Delete Pattern' +
                    '</button>' +
                '</div>' +
                '<div class="hpmsf-pattern-categories">' +
                    '<label>Apply to categories:</label>' +
                    '<div class="hpmsf-cat-checkboxes">' + catBoxes + '</div>' +
                '</div>' +
                '<div class="hpmsf-pattern-steps">' +
                    '<div class="hpmsf-steps-list" data-pattern="' + pi + '"></div>' +
                    '<button type="button" class="hpmsf-add-step button button-small" data-pattern="' + pi + '">+ Add Step</button>' +
                    '<p class="hpmsf-pattern-summary">Assigned: <strong class="hpmsf-assigned-count">0</strong> / ' + total + '. Remaining fields go into last step automatically.</p>' +
                '</div>' +
                '<div class="hpmsf-pattern-visual">' +
                    '<div class="hpmsf-visual-label">Field distribution:</div>' +
                    '<div class="hpmsf-visual-fields" data-pattern="' + pi + '"></div>' +
                '</div>' +
            '</div>'
        );
    }

    function buildStepRow( pi, si ) {
        return $(
            '<div class="hpmsf-step-row">' +
                '<span class="hpmsf-step-num-badge">' + ( si + 1 ) + '</span>' +
                '<input type="text" name="hpmsf_patterns[' + pi + '][steps][' + si + '][title]" ' +
                       'placeholder="Step name\u2026" class="hpmsf-step-title-input regular-text">' +
                '<label class="hpmsf-count-label">Fields: ' +
                    '<input type="number" name="hpmsf_patterns[' + pi + '][steps][' + si + '][count]" ' +
                           'value="0" min="0" max="50" class="hpmsf-step-count-input small-text">' +
                '</label>' +
                '<button type="button" class="hpmsf-remove-step button-link">' +
                    '<span class="dashicons dashicons-no-alt"></span>' +
                '</button>' +
            '</div>'
        );
    }

    /* ── Update visual field distribution for one pattern ─────────────── */

    function updatePatternPreview( $card ) {
        var $visual   = $card.find( '.hpmsf-visual-fields' );
        var $counter  = $card.find( '.hpmsf-assigned-count' );
        var $steps    = $card.find( '.hpmsf-step-row' );
        var stepCount = $steps.length;

        // Build array of step counts
        var counts = [];
        $steps.each( function( i ) {
            counts.push( parseInt( $( this ).find( '.hpmsf-step-count-input' ).val(), 10 ) || 0 );
        } );

        // Distribute fields into steps
        var cursor   = 0;
        var assigned = 0;
        var stepFields = []; // stepFields[i] = array of field objects

        counts.forEach( function( count, i ) {
            var isLast  = ( i === stepCount - 1 );
            var slice   = isLast ? fields.slice( cursor ) : fields.slice( cursor, cursor + count );
            stepFields.push( slice );
            if ( ! isLast ) { cursor += count; }
            assigned += slice.length;
        } );

        $counter.text( Math.min( assigned, total ) );

        // Build visual blocks
        $visual.empty();
        stepFields.forEach( function( slice, i ) {
            var color  = STEP_COLORS[ i % STEP_COLORS.length ];
            var $block = $( '<div class="hpmsf-visual-step">' )
                .css( 'border-color', color );

            var $label = $( '<div class="hpmsf-visual-step-label">' )
                .css( 'background', color )
                .text( 'Step ' + ( i + 1 ) );

            $block.append( $label );

            if ( slice.length ) {
                slice.forEach( function( f ) {
                    $block.append(
                        $( '<span class="hpmsf-visual-field-chip' + ( f.core ? ' is-core' : '' ) + '">' )
                            .text( f.label )
                            .css( 'border-color', color )
                    );
                } );
            } else {
                $block.append( $( '<span class="hpmsf-visual-field-chip is-empty">' ).text( '—' ) );
            }

            $visual.append( $block );
        } );

        // Also update the global field tag colors
        updateFieldTagColors();
    }

    /* ── Color field tags in the reference list by which pattern uses them ── */

    function updateFieldTagColors() {
        // Reset all tags
        $( '.hpmsf-field-tag' ).css( { background: '', color: '', 'border-color': '' } );

        // For simplicity, color based on the first pattern's distribution
        var $firstCard = $( '.hpmsf-pattern-card' ).first();
        if ( ! $firstCard.length ) { return; }

        var $steps    = $firstCard.find( '.hpmsf-step-row' );
        var stepCount = $steps.length;
        var cursor    = 0;

        $steps.each( function( i ) {
            var count  = parseInt( $( this ).find( '.hpmsf-step-count-input' ).val(), 10 ) || 0;
            var isLast = ( i === stepCount - 1 );
            var color  = STEP_COLORS[ i % STEP_COLORS.length ];
            var end    = isLast ? total : Math.min( cursor + count, total );

            for ( var j = cursor; j < end; j++ ) {
                $( '.hpmsf-field-tag[data-index="' + j + '"]' ).css( {
                    background: color, color: '#fff', 'border-color': color
                } );
            }
            if ( ! isLast ) { cursor = end; }
        } );
    }

    function escHtml( s ) {
        return ( s || '' )
            .replace( /&/g, '&amp;' ).replace( /</g, '&lt;' ).replace( />/g, '&gt;' );
    }

    /* ── Init all existing pattern previews on load ───────────────────── */

    $( '.hpmsf-pattern-card' ).each( function() {
        updatePatternPreview( $( this ) );
    } );

} )( window.jQuery );
