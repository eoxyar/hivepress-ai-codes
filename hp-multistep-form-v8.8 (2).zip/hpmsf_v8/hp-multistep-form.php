<?php
/**
 * Plugin Name: HivePress Multi-Step Form
 * Plugin URI:  https://example.com
 * Description: Transforms the HivePress Add Listing form into a configurable multi-step wizard. Define steps and assign fields via the admin panel.
 * Version:     1.0.0
 * Author:      Your Name
 * Text Domain: hp-multistep-form
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

defined( 'ABSPATH' ) || exit;

define( 'HPMSF_VERSION', '1.7.9' );
define( 'HPMSF_FILE',    __FILE__ );
define( 'HPMSF_DIR',     plugin_dir_path( __FILE__ ) );
define( 'HPMSF_URL',     plugin_dir_url( __FILE__ ) );

add_action( 'plugins_loaded', 'hpmsf_boot', 20 );

function hpmsf_boot() {
    if ( ! class_exists( 'HivePress\\Core' ) ) {
        add_action( 'admin_notices', function () {
            echo '<div class="notice notice-error"><p>'
                . esc_html__( 'HivePress Multi-Step Form requires HivePress to be installed and active.', 'hp-multistep-form' )
                . '</p></div>';
        } );
        return;
    }

    require_once HPMSF_DIR . 'includes/class-admin.php';
    require_once HPMSF_DIR . 'includes/class-scripts.php';

    HPMSF_Admin::init();
    HPMSF_Scripts::init();
}
