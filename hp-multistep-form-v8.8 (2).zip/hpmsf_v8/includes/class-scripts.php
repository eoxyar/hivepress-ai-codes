<?php
defined( 'ABSPATH' ) || exit;

class HPMSF_Scripts {

    public static function init() {
        add_action( 'wp_enqueue_scripts', array( __CLASS__, 'frontend' ) );
    }

    public static function frontend() {
        if ( ! HPMSF_Admin::is_enabled() ) { return; }

        $patterns = HPMSF_Admin::get_patterns();
        if ( empty( $patterns ) ) { return; }

        // Build category→pattern map for the frontend
        $default_steps = array();
        $cat_map        = array(); // cat_id => [ {title, count}, ... ]

        foreach ( $patterns as $p ) {
            $steps = $p['steps'] ?? array();
            if ( count( $steps ) < 2 ) { continue; }

            if ( $p['is_default'] ) {
                $default_steps = $steps;
            }

            foreach ( ( $p['categories'] ?? array() ) as $cat_id ) {
                $cat_map[ intval( $cat_id ) ] = $steps;
            }
        }

        // Need at least a default with 2+ steps
        if ( count( $default_steps ) < 2 && empty( $cat_map ) ) { return; }

        wp_enqueue_script( 'hpmsf-frontend', HPMSF_URL . 'assets/js/frontend.js', array( 'jquery' ), HPMSF_VERSION, true );
        wp_enqueue_style(  'hpmsf-frontend', HPMSF_URL . 'assets/css/frontend.css', array(), HPMSF_VERSION );

        wp_add_inline_script(
            'hpmsf-frontend',
            'window.hpmsfData = ' . wp_json_encode( array(
                'defaultSteps' => $default_steps,
                'catMap'       => $cat_map,   // { "35": [ {title,count},... ], ... }
                'style'        => HPMSF_Admin::get_style(),
                'i18n'         => array(
                    'next'      => __( 'Next', 'hp-multistep-form' ),
                    'back'      => __( 'Back', 'hp-multistep-form' ),
                    'submit'    => __( 'Submit Listing', 'hp-multistep-form' ),
                    'step'      => __( 'Step', 'hp-multistep-form' ),
                    'of'        => __( 'of', 'hp-multistep-form' ),
                    'required'  => __( 'Please fill in all required fields.', 'hp-multistep-form' ),
                ),
            ) ) . ';',
            'before'
        );
    }
}
