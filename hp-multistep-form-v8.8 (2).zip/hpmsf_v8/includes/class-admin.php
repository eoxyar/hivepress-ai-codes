<?php
defined( 'ABSPATH' ) || exit;

class HPMSF_Admin {

    const OPTION_PATTERNS = 'hpmsf_patterns';  // [ { id, name, default, categories[], steps[ {title,count} ] } ]
    const OPTION_ENABLED  = 'hpmsf_enabled';
    const OPTION_STYLE    = 'hpmsf_style';

    public static function init() {
        add_action( 'admin_menu',            array( __CLASS__, 'add_menu' ) );
        add_action( 'admin_init',            array( __CLASS__, 'handle_save' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
    }

    /* ── Menu ─────────────────────────────────────────────────────────── */

    public static function add_menu() {
        add_submenu_page(
            'options-general.php',
            __( 'Multi-Step Listing Form', 'hp-multistep-form' ),
            __( 'Multi-Step Form', 'hp-multistep-form' ),
            'manage_options',
            'hpmsf-settings',
            array( __CLASS__, 'render_page' )
        );
    }

    /* ── Enqueue ──────────────────────────────────────────────────────── */

    public static function enqueue( $hook ) {
        if ( $hook !== 'settings_page_hpmsf-settings' ) { return; }
        wp_enqueue_script( 'hpmsf-admin', HPMSF_URL . 'assets/js/admin.js', array( 'jquery' ), HPMSF_VERSION, true );
        wp_enqueue_style( 'hpmsf-admin', HPMSF_URL . 'assets/css/admin.css', array(), HPMSF_VERSION );
        wp_localize_script( 'hpmsf-admin', 'hpmsfAdmin', array(
            'fields'     => self::get_all_fields(),
            'categories' => self::get_categories(),
            'patterns'   => self::get_patterns(),
            'i18n'       => array(
                'addStep'      => __( 'Add Step', 'hp-multistep-form' ),
                'removeStep'   => __( 'Remove', 'hp-multistep-form' ),
                'stepName'     => __( 'Step name\u2026', 'hp-multistep-form' ),
                'fields'       => __( 'Number of fields:', 'hp-multistep-form' ),
                'remaining'    => __( '(remaining fields)', 'hp-multistep-form' ),
                'none'         => __( '(none)', 'hp-multistep-form' ),
            ),
        ) );
    }

    /* ── Get ordered field list: core first, attributes middle, description last ── */

    public static function get_all_fields() {
        $fields = array();

        // Core fields — fixed order, description always last
        $core_top = array(
            array( 'slug' => 'categories', 'label' => __( 'Category', 'hp-multistep-form' ), 'core' => true ),
            array( 'slug' => 'images',     'label' => __( 'Images', 'hp-multistep-form' ),   'core' => true ),
            array( 'slug' => 'title',      'label' => __( 'Title', 'hp-multistep-form' ),    'core' => true ),
            array( 'slug' => 'location',   'label' => __( 'Location', 'hp-multistep-form' ), 'core' => true ),
        );

        foreach ( $core_top as $f ) { $fields[] = $f; }

        // Custom HP listing attributes in menu_order
        $raw = get_posts( array(
            'post_type'      => 'hp_listing_attribute',
            'posts_per_page' => -1,
            'post_status'    => 'publish',
            'orderby'        => 'menu_order',
            'order'          => 'ASC',
        ) );
        foreach ( $raw as $post ) {
            $fields[] = array( 'slug' => $post->post_name, 'label' => $post->post_title, 'core' => false );
        }

        // Description always last
        $fields[] = array( 'slug' => 'description', 'label' => __( 'Description', 'hp-multistep-form' ), 'core' => true );

        return $fields;
    }

    /* ── Get HP listing categories ────────────────────────────────────── */

    public static function get_categories() {
        $terms = get_terms( array(
            'taxonomy'   => 'hp_listing_category',
            'hide_empty' => false,
            'orderby'    => 'name',
            'order'      => 'ASC',
        ) );
        if ( is_wp_error( $terms ) ) { return array(); }
        $out = array();
        foreach ( $terms as $t ) {
            $out[] = array( 'id' => $t->term_id, 'name' => $t->name, 'slug' => $t->slug );
        }
        return $out;
    }

    /* ── Patterns CRUD ────────────────────────────────────────────────── */

    public static function get_patterns() {
        $patterns = get_option( self::OPTION_PATTERNS, array() );
        // Ensure at least one default pattern exists
        if ( empty( $patterns ) ) {
            $patterns = array(
                array(
                    'id'         => 1,
                    'name'       => __( 'Default', 'hp-multistep-form' ),
                    'is_default' => true,
                    'categories' => array(),
                    'steps'      => array(
                        array( 'title' => __( 'Basic Info', 'hp-multistep-form' ), 'count' => 3 ),
                        array( 'title' => __( 'Details', 'hp-multistep-form' ),    'count' => 3 ),
                        array( 'title' => __( 'Finish', 'hp-multistep-form' ),     'count' => 0 ),
                    ),
                ),
            );
        }
        return $patterns;
    }

    public static function is_enabled() { return (bool) get_option( self::OPTION_ENABLED, 0 ); }
    public static function get_style()  { return get_option( self::OPTION_STYLE, 'progress' ); }

    /* ── Handle save ──────────────────────────────────────────────────── */

    public static function handle_save() {
        if ( ! isset( $_POST['hpmsf_save'] ) ) { return; }
        if ( ! check_admin_referer( 'hpmsf_save_settings' ) ) { return; }
        if ( ! current_user_can( 'manage_options' ) ) { return; }

        update_option( self::OPTION_ENABLED, isset( $_POST['hpmsf_enabled'] ) ? 1 : 0 );
        update_option( self::OPTION_STYLE, sanitize_text_field( $_POST['hpmsf_style'] ?? 'progress' ) );

        $raw_patterns  = $_POST['hpmsf_patterns'] ?? array();
        $default_id    = intval( $_POST['hpmsf_default_pattern'] ?? 0 );
        $patterns      = array();
        $used_cats     = array(); // track category→pattern to enforce one-to-one

        foreach ( $raw_patterns as $rp ) {
            $id   = intval( $rp['id'] ?? 0 );
            $name = sanitize_text_field( $rp['name'] ?? '' );
            if ( ! $name ) { continue; }

            // Sanitize categories — skip already assigned ones
            $cats = array();
            if ( ! empty( $rp['categories'] ) && is_array( $rp['categories'] ) ) {
                foreach ( $rp['categories'] as $cid ) {
                    $cid = intval( $cid );
                    if ( $cid && ! isset( $used_cats[ $cid ] ) ) {
                        $cats[]            = $cid;
                        $used_cats[ $cid ] = true;
                    }
                }
            }

            // Sanitize steps
            $steps = array();
            if ( ! empty( $rp['steps'] ) && is_array( $rp['steps'] ) ) {
                foreach ( $rp['steps'] as $s ) {
                    $steps[] = array(
                        'title' => sanitize_text_field( $s['title'] ?? '' ),
                        'count' => max( 0, intval( $s['count'] ?? 0 ) ),
                    );
                }
            }

            $patterns[] = array(
                'id'         => $id ?: ( count( $patterns ) + 1 ),
                'name'       => $name,
                'is_default' => ( $id === $default_id ),
                'categories' => $cats,
                'steps'      => $steps,
            );
        }

        // Ensure exactly one default
        $has_default = false;
        foreach ( $patterns as &$p ) {
            if ( $p['is_default'] ) { $has_default = true; break; }
        }
        unset( $p );
        if ( ! $has_default && ! empty( $patterns ) ) {
            $patterns[0]['is_default'] = true;
        }

        update_option( self::OPTION_PATTERNS, $patterns );

        add_action( 'admin_notices', function() {
            echo '<div class="notice notice-success is-dismissible"><p>'
                . esc_html__( 'Settings saved.', 'hp-multistep-form' )
                . '</p></div>';
        } );
    }

    /* ── Render page ──────────────────────────────────────────────────── */

    public static function render_page() {
        $patterns   = self::get_patterns();
        $style      = self::get_style();
        $fields     = self::get_all_fields();
        $categories = self::get_categories();
        $total      = count( $fields );

        // Find current default pattern id
        $default_id = 0;
        foreach ( $patterns as $p ) {
            if ( $p['is_default'] ) { $default_id = $p['id']; break; }
        }
        ?>
        <div class="wrap hpmsf-wrap">
            <h1><?php esc_html_e( 'Multi-Step Listing Form', 'hp-multistep-form' ); ?></h1>
            <p class="description"><?php esc_html_e( 'Create step patterns and assign them to listing categories. The default pattern applies to all categories without a specific assignment.', 'hp-multistep-form' ); ?></p>

            <form method="post" id="hpmsf-form">
                <?php wp_nonce_field( 'hpmsf_save_settings' ); ?>
                <input type="hidden" name="hpmsf_save" value="1">
                <input type="hidden" name="hpmsf_default_pattern" id="hpmsf-default-pattern-input" value="<?php echo esc_attr( $default_id ); ?>">

                <!-- Enable + Style -->
                <div class="hpmsf-header-row">
                    <label class="hpmsf-toggle">
                        <input type="checkbox" name="hpmsf_enabled" value="1" <?php checked( self::is_enabled() ); ?>>
                        <span class="hpmsf-toggle-slider"></span>
                        <span class="hpmsf-toggle-label"><?php esc_html_e( 'Enable Multi-Step Form', 'hp-multistep-form' ); ?></span>
                    </label>
                    <div class="hpmsf-style-picker">
                        <label><?php esc_html_e( 'Progress Style:', 'hp-multistep-form' ); ?></label>
                        <select name="hpmsf_style">
                            <option value="progress" <?php selected( $style, 'progress' ); ?>><?php esc_html_e( 'Progress Bar', 'hp-multistep-form' ); ?></option>
                            <option value="steps"    <?php selected( $style, 'steps' ); ?>><?php esc_html_e( 'Step Numbers', 'hp-multistep-form' ); ?></option>
                            <option value="minimal"  <?php selected( $style, 'minimal' ); ?>><?php esc_html_e( 'Minimal', 'hp-multistep-form' ); ?></option>
                        </select>
                    </div>
                </div>

                <!-- Field reference -->
                <div class="hpmsf-field-reference">
                    <h3><?php esc_html_e( 'Form Fields (in order)', 'hp-multistep-form' ); ?></h3>
                    <p class="description"><?php printf( esc_html__( '%d fields total — core fields first, custom attributes in HivePress order, description last. Step patterns distribute these fields sequentially.', 'hp-multistep-form' ), $total ); ?></p>
                    <div class="hpmsf-field-list" id="hpmsf-field-list">
                        <?php foreach ( $fields as $i => $f ) : ?>
                            <span class="hpmsf-field-tag <?php echo $f['core'] ? 'is-core' : ''; ?>" data-index="<?php echo $i; ?>" title="<?php echo esc_attr( $f['slug'] ); ?>">
                                <span class="hpmsf-field-num"><?php echo $i + 1; ?></span>
                                <?php echo esc_html( $f['label'] ); ?>
                                <?php if ( $f['core'] ) : ?><em>core</em><?php endif; ?>
                            </span>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Patterns -->
                <div class="hpmsf-patterns-wrap">
                    <h3><?php esc_html_e( 'Step Patterns', 'hp-multistep-form' ); ?></h3>

                    <div id="hpmsf-patterns-list">
                        <?php foreach ( $patterns as $pi => $pattern ) : ?>
                            <?php self::render_pattern( $pi, $pattern, $fields, $categories, $default_id ); ?>
                        <?php endforeach; ?>
                    </div>

                    <button type="button" id="hpmsf-add-pattern" class="button button-secondary">
                        + <?php esc_html_e( 'Add Pattern', 'hp-multistep-form' ); ?>
                    </button>
                </div>

                <p class="submit">
                    <button type="submit" class="button button-primary button-large"><?php esc_html_e( 'Save Settings', 'hp-multistep-form' ); ?></button>
                </p>
            </form>
        </div>
        <?php
    }

    /* ── Render a single pattern card ─────────────────────────────────── */

    public static function render_pattern( $pi, $pattern, $fields, $categories, $default_id ) {
        $pid        = $pattern['id'];
        $is_default = $pattern['is_default'];
        $name       = $pattern['name'] ?? '';
        $steps      = $pattern['steps'] ?? array();
        $pat_cats   = $pattern['categories'] ?? array();
        ?>
        <div class="hpmsf-pattern-card <?php echo $is_default ? 'is-default' : ''; ?>"
             data-pattern-index="<?php echo esc_attr( $pi ); ?>"
             data-pattern-id="<?php echo esc_attr( $pid ); ?>">

            <input type="hidden" name="hpmsf_patterns[<?php echo $pi; ?>][id]" value="<?php echo esc_attr( $pid ); ?>">

            <!-- Pattern header -->
            <div class="hpmsf-pattern-header">
                <div class="hpmsf-pattern-header-left">
                    <?php if ( $is_default ) : ?>
                        <span class="hpmsf-default-badge"><?php esc_html_e( 'DEFAULT', 'hp-multistep-form' ); ?></span>
                    <?php else : ?>
                        <button type="button" class="hpmsf-set-default button button-small" data-id="<?php echo esc_attr( $pid ); ?>">
                            <?php esc_html_e( 'Set as Default', 'hp-multistep-form' ); ?>
                        </button>
                    <?php endif; ?>
                    <input type="text"
                           name="hpmsf_patterns[<?php echo $pi; ?>][name]"
                           value="<?php echo esc_attr( $name ); ?>"
                           placeholder="<?php esc_attr_e( 'Pattern name\u2026', 'hp-multistep-form' ); ?>"
                           class="hpmsf-pattern-name-input regular-text">
                </div>
                <button type="button" class="hpmsf-remove-pattern button-link">
                    <span class="dashicons dashicons-trash"></span>
                    <?php esc_html_e( 'Delete Pattern', 'hp-multistep-form' ); ?>
                </button>
            </div>

            <!-- Category assignment (hidden for default) -->
            <?php if ( ! $is_default ) : ?>
            <div class="hpmsf-pattern-categories">
                <label><?php esc_html_e( 'Apply to categories:', 'hp-multistep-form' ); ?></label>
                <div class="hpmsf-cat-checkboxes">
                    <?php foreach ( $categories as $cat ) : ?>
                        <label class="hpmsf-cat-label">
                            <input type="checkbox"
                                   name="hpmsf_patterns[<?php echo $pi; ?>][categories][]"
                                   value="<?php echo esc_attr( $cat['id'] ); ?>"
                                   <?php checked( in_array( $cat['id'], $pat_cats ) ); ?>>
                            <?php echo esc_html( $cat['name'] ); ?>
                        </label>
                    <?php endforeach; ?>
                    <?php if ( empty( $categories ) ) : ?>
                        <em><?php esc_html_e( 'No listing categories found.', 'hp-multistep-form' ); ?></em>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Steps for this pattern -->
            <div class="hpmsf-pattern-steps">
                <div class="hpmsf-steps-list" data-pattern="<?php echo esc_attr( $pi ); ?>">
                    <?php foreach ( $steps as $si => $step ) : ?>
                        <?php self::render_step_row( $pi, $si, $step ); ?>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="hpmsf-add-step button button-small" data-pattern="<?php echo esc_attr( $pi ); ?>">
                    + <?php esc_html_e( 'Add Step', 'hp-multistep-form' ); ?>
                </button>
                <p class="hpmsf-pattern-summary">
                    <?php esc_html_e( 'Assigned:', 'hp-multistep-form' ); ?>
                    <strong class="hpmsf-assigned-count">0</strong> / <?php echo count( $fields ); ?>.
                    <?php esc_html_e( 'Remaining fields go into last step automatically.', 'hp-multistep-form' ); ?>
                </p>
            </div>

            <!-- Visual field distribution for this pattern -->
            <div class="hpmsf-pattern-visual">
                <div class="hpmsf-visual-label"><?php esc_html_e( 'Field distribution:', 'hp-multistep-form' ); ?></div>
                <div class="hpmsf-visual-fields" data-pattern="<?php echo esc_attr( $pi ); ?>">
                    <!-- Filled by JS -->
                </div>
                <p class="hpmsf-visual-note"><?php esc_html_e( 'For visual reference only — actual field order depends on your HivePress form configuration.', 'hp-multistep-form' ); ?></p>
            </div>

        </div>
        <?php
    }

    /* ── Render a step row inside a pattern ───────────────────────────── */

    public static function render_step_row( $pi, $si, $step = array() ) {
        ?>
        <div class="hpmsf-step-row">
            <span class="hpmsf-step-num-badge"><?php echo $si + 1; ?></span>
            <input type="text"
                   name="hpmsf_patterns[<?php echo $pi; ?>][steps][<?php echo $si; ?>][title]"
                   value="<?php echo esc_attr( $step['title'] ?? '' ); ?>"
                   placeholder="<?php esc_attr_e( 'Step name\u2026', 'hp-multistep-form' ); ?>"
                   class="hpmsf-step-title-input regular-text">
            <label class="hpmsf-count-label">
                <?php esc_html_e( 'Fields:', 'hp-multistep-form' ); ?>
                <input type="number"
                       name="hpmsf_patterns[<?php echo $pi; ?>][steps][<?php echo $si; ?>][count]"
                       value="<?php echo esc_attr( $step['count'] ?? 0 ); ?>"
                       min="0" max="50"
                       class="hpmsf-step-count-input small-text">
            </label>
            <button type="button" class="hpmsf-remove-step button-link">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <?php
    }
}
